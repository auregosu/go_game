IMAGE = "assets/image/"
SOUND = "assets/sound/"
WIDTH = 648*2
HEIGHT = 400*2
TEXT_SMALL = 40
TEXT_NORMAL = 50
TEXT_BIG = 80
