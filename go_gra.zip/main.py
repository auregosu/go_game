import pygame
from game_manager import GameManager

if __name__ == "__main__":
    game_manager = GameManager()
    game_manager.run()